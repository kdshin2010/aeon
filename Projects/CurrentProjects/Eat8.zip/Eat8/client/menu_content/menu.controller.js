(function() {
	'use strict';

	angular
	.module('menuApp')
	.controller('MenuCtrl', MenuCtrlFunction);

	function MenuCtrlFunction($scope, $location, MenuFactory) {
		$scope.addCategory = addCategory
		$scope.addItem = addItem
		$scope.removeCategory = removeCategory
		$scope.categories;
		$scope.items

		getCategories();//get MenuCategores
		getMenuItems();

		function addCategory() {
			MenuFactory.addCategory($scope.newCategory)
			$scope.newCategory = {}
			getCategories();
		}

		function removeCategory(x) {
			MenuFactory.removeCategory(x, function(data) {
				$scope.categories = data;
				MenuFactory.obtainCategoires(function(data) {
				$scope.categories = data;
				})
			})

		}

		function getCategories() {
			MenuFactory.getCategories()
			.then(function(data) {
				$scope.categories = data;
				console.log(data)
			})
			.catch(function() {
				console.log('error!!')
			})
		}

		function addItem() {
			console.log('here')
			MenuFactory.addItem({id: $scope.selectedCategory, name: $scope.newItem.name, price: $scope.newItem.price, description: $scope.newItem.description })
			.then(function(data) {
				console.log('this is my data!!')
				console.log(data)
			})
			.catch(function(){
				console.log('error!')
			})
			$scope.newItem = {}
		}

		function getMenuItems() {
			MenuFactory.getMenuItems()
			.then(function(data) {
				$scope.items = data;
				console.log(data)
			})
			.catch(function(){
				console.log('error')
			})
		}

	}


})()